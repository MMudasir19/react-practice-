const express = require("express");
const app = express();

app.get("/", (req, res) => {
  res.send("e-dashboard backend working");
});

app.listen(5000);
