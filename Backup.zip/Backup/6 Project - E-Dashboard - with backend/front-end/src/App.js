import { Route, Routes } from "react-router-dom";
import "./App.scss";
import Navbar from "./components/Navbar";
import Bottom from "./components/Bottom";

function App() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route exact path="/" element={<h1>Product component</h1>} />
        <Route exact path="/add" element={<h1>Add Product component</h1>} />
        <Route exact path="/update" element={<h1>Update Products </h1>} />
        <Route exact path="/logout" element={<h1>Logout component</h1>} />
        <Route exact path="/profile" element={<h1>Profile component</h1>} />
      </Routes>
      <Bottom />
    </div>
  );
}

export default App;
