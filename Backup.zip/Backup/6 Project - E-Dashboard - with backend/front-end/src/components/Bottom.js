import React from "react";

export default function Bottom() {
  return (
    <div className="footer">
      {/* <h2>Bottom</h2> */}
      <div>
        <h3 className="h1">Working</h3>
        <p>
          3Schools is optimized for learning and training. might be simplified
          to improve reading and learning. Tutorials, references, and
        </p>
      </div>
      <div>
        <h3 className="h1">Platforms</h3>
        <p>
          mples are constantly reviewed to avoid errors, but we cannot warrant
          full correctness of all content. While using W3Schools, you agree to
          hav
        </p>
      </div>
      <div>
        <h3 className="h1">Credits</h3>
        <p className="credits">
          exae read and <br />
          our terms o<br />
          cookie and privacy<br />
          1999-202
        </p>
      </div>
    </div>
  );
}
