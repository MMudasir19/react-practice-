import React from "react";
import { useDispatch } from "react-redux";
import { bindActionCreators } from "redux";
import * as actionCreators from "../state/action-creators/index";
import { useSelector } from "react-redux";

export default function Shop() {
  const balance = useSelector((state) => state.amount);
  const dispatch = useDispatch();
  const { withdrawMoney, depositMoney } = bindActionCreators(
    actionCreators,
    dispatch
  );
  return (
    <div className="container my-3 text-center">
      <h1>Deposit or Withdraw Money</h1>
      <button
        type="button"
        className="btn btn-danger mx-3 my-3 fs-4"
        onClick={() => {
          withdrawMoney(100);
        }}
      >
        Decrease
      </button>
      <h4 style={{ display: "inline-block" }}>Current Balance : <span style={{color: 'orange'}}>{balance}</span> </h4>
      <button
        type="button"
        className="btn btn-warning mx-3 fs-4"
        onClick={() => {
          depositMoney(100);
        }}
      >
        Increase
      </button>
    </div>
  );
}
