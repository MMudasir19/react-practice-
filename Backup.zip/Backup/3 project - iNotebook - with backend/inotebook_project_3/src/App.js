import "./App.css";
import { Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import About from "./components/About";
import Navbar from "./components/Navbar";
import Alert from "./components/Alert";
import NoteState from "./context/notes/NoteState";
import Signup from "./components/Signup";
import Login from "./components/login";

function App() {
  return (
    <>
      <NoteState>
        <Navbar />
        <Alert />
        <Routes>
          <Route exact path="/">
            <Route index element={<Home />} />
            <Route exact path="about" element={<About />} />
            <Route exact path="login" element={<Login />} />
            <Route exact path="signup" element={<Signup />} />
          </Route>
        </Routes>
      </NoteState>
    </>
  );
}

export default App;
