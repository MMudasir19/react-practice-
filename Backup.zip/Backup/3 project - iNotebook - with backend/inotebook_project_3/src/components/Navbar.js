import React from "react";
import { NavLink, Link, useNavigate } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();

  const handleSignOut = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <nav className="dark navbar navbar-expand-lg bg-body-tertiary dark fixed-top">
      <div className="dark container-fluid">
        <Link className="dark navbar-brand" to="/">
          iNotebook
        </Link>
        <button
          className="dark navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="dark navbar-toggler-icon"></span>
        </button>
        <div
          className="dark collapse navbar-collapse"
          id="navbarSupportedContent"
        >
          <ul className="dark navbar-nav me-auto mb-2 mb-lg-0">
            <li className="dark nav-item">
              <NavLink className="dark nav-link" aria-current="page" to="/">
                Home
              </NavLink>
            </li>
            <li className="dark nav-item">
              <NavLink className="dark nav-link" to="/about">
                About
              </NavLink>
            </li>
            <li className="dark nav-item dropdown">
              <Link
                className="dark nav-link dropdown-toggle"
                to="/a"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
                hidden //ToDo
              >
                Theme
              </Link>
              <ul className="dark dropdown-menu">
                <li>
                  <Link className="dark dropdown-item" to="/m1">
                    Light
                  </Link>
                </li>
                <li>
                  <Link className="dark dropdown-item" to="/m2">
                    Dark
                  </Link>
                </li>
                <li>
                  <hr className="dark dropdown-divider hr" />
                </li>
                <li>
                  <Link className="dark dropdown-item" to="/m3">
                    System Default
                  </Link>
                </li>
              </ul>
            </li>
          </ul>
          {/* <input
              className="dark form-control me-2 searchbar"
              type="search"
              placeholder="Search"
              aria-label="Search"
            /> */}
          {!localStorage.getItem("token") ? (
            <form className="dark d-flex" role="search">
              <Link
                className="btn btn-primary mx-2 button"
                to="/login"
                role="button"
              >
                <b>Login</b>
              </Link>
              <Link
                className="btn btn-warning button"
                to="/signup"
                role="button"
              >
                <b>Signup</b>
              </Link>
            </form>
          ) : (
            <button onClick={handleSignOut} className="btn btn-warning button">
              <b>Sign out</b>
            </button>
          )}
        </div>
      </div>
    </nav>
  );
}
