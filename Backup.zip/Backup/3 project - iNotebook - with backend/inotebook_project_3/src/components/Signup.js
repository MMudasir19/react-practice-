import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import noteContext from "../context/notes/noteContext";

export default function Signup(props) {
  const [credentials, setCredentials] = useState({
    name: "",
    email: "",
    password: "",
    cpassword: "",
  });
  const navigate = useNavigate();
  const context = useContext(noteContext);
  const { toggleAlert } = context;

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { name, email, password } = credentials;
    const response = await fetch("http://localhost:5000/api/auth/createuser", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, password }),
    });
    const json = await response.json();
    if (json.token) {
      // save authtoken and redirect
      localStorage.setItem("token", json.token);
      toggleAlert("Account created successfully", "success");
      navigate("/");
    } else {
      toggleAlert("Invalid Details", "danger");
    }
  };

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  return (
    <div>
      <div className="wrapper mt-4">
        <div className="text-center mt-4 name">Sign Up</div>
        <form className="p-3 mt-3" onSubmit={handleSubmit}>
          <div className="form-field d-flex align-items-center">
            <span className="far fa-user"></span>
            <input
              type="text"
              name="name"
              id="name"
              placeholder="Username"
              value={credentials.name}
              onChange={handleChange}
            />
          </div>
          <div className="form-field d-flex align-items-center">
            <span className="far fa-user"></span>
            <input
              type="text"
              name="email"
              id="email"
              placeholder="Email"
              value={credentials.email}
              onChange={handleChange}
            />
          </div>
          <div className="form-field d-flex align-items-center">
            <span className="fas fa-key"></span>
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Password"
              value={credentials.password}
              onChange={handleChange}
              required
              minLength={5}
            />
          </div>
          <div className="form-field d-flex align-items-center">
            <span className="fas fa-key"></span>
            <input
              type="password"
              name="cpassword"
              id="cpassword"
              placeholder="Confirm Password"
              value={credentials.cpassword}
              onChange={handleChange}
              required
              minLength={5}
            />
          </div>
          <button className="btn mt-3 text-dark loginSignup">Sign Up</button>
        </form>
        <div className="text-center fs-6">
          <span className="alreadyAnAccount">Have already an account?</span>{" "}
          <Link to="/login">Log in</Link>
        </div>
      </div>
    </div>
  );
}
