import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import noteContext from "../context/notes/noteContext";

export default function Login() {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const navigate = useNavigate();
  const context = useContext(noteContext);
  const { toggleAlert } = context;

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { email, password } = credentials;
    const response = await fetch("http://localhost:5000/api/auth/loginuser", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    });
    const json = await response.json();
    if (json.token) {
      // save authtoken and redirect
      localStorage.setItem("token", json.token);
      toggleAlert("Logged in successfully", "success");
      navigate("/");
    } else {
      // debugger;
      toggleAlert("Invalid Credentials", "danger");
    }
  };

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  return (
    <div>
      <div className="wrapper mt-4">
        <div className="text-center mt-4 name">Log in</div>
        <form onSubmit={handleSubmit} className="p-3 mt-3">
          <div className="form-field d-flex align-items-center">
            <span className="far fa-user"></span>
            <input
              type="text"
              name="email"
              id="email"
              placeholder="Email"
              value={credentials.email}
              onChange={handleChange}
            />
          </div>
          <div className="form-field d-flex align-items-center">
            <span className="fas fa-key"></span>
            <input
              type="password"
              name="password"
              id="password"
              placeholder="Password"
              value={credentials.password}
              onChange={handleChange}
              required
              minLength={5}
              autoComplete="password"
            />
          </div>
          <button className="btn mt-3 text-dark loginSignup">Login</button>
        </form>
        <div className="text-center fs-6">
          <Link to="/forgotPassword">Forget password</Link> or{" "}
          <Link to="/signup">Sign up</Link>
        </div>
      </div>
    </div>
  );
}
