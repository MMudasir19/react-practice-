import React, { useContext, useEffect, useRef, useState } from "react";
import noteContext from "../context/notes/noteContext";
import NewsItem from "./NewsItem";
import { useNavigate } from "react-router-dom";
import { getToken } from "../context/notes/NoteState";
// import FlipMove from "react-flip-move";

export default function Notes(props) {
  const token = getToken();
  const context = useContext(noteContext);
  const { notes, getNotes, editNote, toggleAlert } = context;
  const ref = useRef(null);
  const refClose = useRef(null);
  const navigate = useNavigate();
  const [note, setNote] = useState({
    id: "",
    etitle: "",
    edescription: "",
    // etag: "",
  });

  useEffect(() => {
    if (token) {
      getNotes();
    } else {
      navigate("/login");
    }
    // eslint-disable-next-line
  }, []);

  const updateNote = (currentNote) => {
    ref.current.click();
    setNote({
      id: currentNote._id,
      etitle: currentNote.title,
      edescription: currentNote.description,
      // etag: currentNote.tag,
    });
  };

  const handleChange = (e) => {
    setNote({ ...note, [e.target.name]: e.target.value });
  };
  
  const handleClick = (e) => {
    e.preventDefault();
    refClose.current.click();
    editNote(
      note.id,
      note.etitle,
      note.edescription
      // note.etag
    );
    toggleAlert("Note Updated Successfully", "success");
  };

  return (
    <div className="container">
      {/* Button trigger modal / to show pop-up  */}
      <button
        type="button"
        className="d-none btn btn-primary"
        data-bs-toggle="modal"
        data-bs-target="#exampleModal"
        ref={ref}
      >
        Launch demo modal
      </button>

      {/* <!-- Modal --> */}
      <div
        className="modal fade "
        id="exampleModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog ">
          <div className="modal-content">
            <div className="modal-header darkPopup">
              <h1 className="modal-title fs-5" id="exampleModalLabel">
                Edit Note
              </h1>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            {/* after pop-up */}
            <div className="modal-body darkPopup">
              <form onSubmit={handleClick}>
                <div className="mb-3">
                  <input
                    name="etitle"
                    type="text"
                    className="form-control type"
                    id="etitle"
                    aria-describedby="eTitle"
                    placeholder="Type Title"
                    onChange={handleChange}
                    value={note.etitle}
                    minLength={1}
                    required
                  />
                </div>
                <div className="mb-3">
                  <textarea
                    name="edescription"
                    type="text"
                    className="form-control type"
                    id="edescription"
                    aria-describedby="eDescription"
                    placeholder="Type Description"
                    onChange={handleChange}
                    value={note.edescription}
                    minLength={1}
                    required
                  />
                </div>
                {/* <div className="mb-3">
                  <input
                    name="etag"
                    type="text"
                    className="form-control type"
                    id="etag"
                    aria-describedby="etag"
                    placeholder="Type tag"
                    onChange={handleChange}
                    value={note.etag}
                    minLength={1}
                    required
                  />
                </div> */}
              </form>
            </div>
            <div className="modal-footer darkPopup">
              <button
                type="button"
                className="btn btn-secondary"
                data-bs-dismiss="modal"
                ref={refClose}
              >
                Close
              </button>
              <button
                disabled={
                  note.etitle.length < 1 || note.edescription.length < 1
                  //  ||
                  // note.etag.length < 1
                }
                type="button"
                className="btn btn-primary"
              >
                Save changes
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="yourNotesHeading">
        <h1 className="headingFontFamily">Your Notes</h1>
        <h2 className="headingFontFamily" style={{ marginRight: "2%" }}>
          Total : {notes.length}{" "}
        </h2>
      </div>
      {/* <FlipMove> */}
      <div className="row">
        {notes.map((e) => {
          return (
            <NewsItem
              key={e._id}
              notes={e}
              updateNote={updateNote}
              toggleAlert={props.toggleAlert}
            />
          );
        })}
      </div>
      {/* </FlipMove> */}
    </div>
  );
}
