import React, { useContext } from "react";
import noteContext from "../context/notes/noteContext";

export default function NewsItem(props) {
  const context = useContext(noteContext);
  const { deleteNote, toggleAlert } = context;
  const { notes, updateNote } = props;

  return (
    <div className="col-md-4">
      <div className="card my-3">
        <div className="card-body">
          <h5 className="card-title"> {notes.title} </h5>
          <p className="card-text"> {notes.description} </p>
          <div className="noteIcons">
            <i
              onClick={() => {
                deleteNote(notes._id);
                toggleAlert("Note deleted", "danger");
              }}
              className="fa-solid fa-trash"
            ></i>
            <i
              onClick={() => {
                updateNote(notes);
              }}
              className="fa-regular fa-pen-to-square mx-3"
            ></i>
          </div>
        </div>
      </div>
    </div>
  );
}
