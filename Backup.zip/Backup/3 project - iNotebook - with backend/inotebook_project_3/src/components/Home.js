import React from "react";
import AddNote from "./AddNote";
import Notes from "./Notes";

export default function Home(props) {
  return (
    <div className="afterLogin">
      <div className="AddNote">
        <AddNote toggleAlert={props.toggleAlert} />
      </div>
      <div className="notesList">
        <Notes toggleAlert={props.toggleAlert} />
      </div>
    </div>
  );
}
