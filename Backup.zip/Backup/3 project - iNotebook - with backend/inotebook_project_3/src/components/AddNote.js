import React, { useContext, useState } from "react";
import noteContext from "../context/notes/noteContext";

export default function AddNote(props) {
  const context = useContext(noteContext);
  const { addNote, toggleAlert } = context;
  const [note, setNote] = useState({
    title: "",
    description: "",
    // tag: "",
  });

  const handleClick = (e) => {
    e.preventDefault();
    addNote(note.title, note.description, 
      // note.tag
      );
    setNote({
      title: "",
      description: "",
      // tag: "",
    });
    toggleAlert("New Note Created", "success");
  };

  const handleChange = (e) => {
    setNote({ ...note, [e.target.name]: e.target.value });
  };

  return (
    <div className="container addNewNote">
      <h1 className="mb-4">Add new Note</h1>
      <form onSubmit={handleClick}>
        <div className="mb-3">
          <input
            name="title"
            type="text"
            className="form-control type"
            id="title"
            aria-describedby="Title"
            placeholder="Type Title"
            onChange={handleChange}
            minLength={1}
            required
            value={note.title}
          />
        </div>
        <div className="mb-3">
          <textarea
            name="description"
            type="text"
            className="form-control type"
            id="description"
            aria-describedby="Description"
            placeholder="Type Description"
            onChange={handleChange}
            minLength={1}
            required
            value={note.description}
          />
        </div>
        {/* <div className="mb-3">
          <input
            name="tag"
            type="text"
            className="form-control type"
            id="tag"
            aria-describedby="tag"
            placeholder="Type tag"
            onChange={handleChange}
            minLength={3}
            required
            value={note.tag}
          />
        </div> */}
        <div className="btn-lg">
          <button
            disabled={
              note.title.length < 1 ||
              note.description.length < 1
              //  ||
              // note.tag.length < 3
            }
            // type="submit"
            className="btn btn-primary btn-lg"
          >
            <span style={{fontSize: "200%"}}>Add Note</span>
          </button>
        </div>
      </form>
    </div>
  );
}
