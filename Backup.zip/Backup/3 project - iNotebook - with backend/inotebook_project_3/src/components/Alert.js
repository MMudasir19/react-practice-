import React, { useContext } from "react";
import noteContext from "../context/notes/noteContext";

export default function Alert(props) {
  const context = useContext(noteContext);
  const { alert } = context;

  function name(word) {
    if (word === "danger") {
      word = "error";
    }
    return word;
  }

  return (
    <div style={{ height: "50px" }}>
      {alert && (
        <div className={`alert alert-${alert.type}`} role="alert">
          <strong> {name(alert.type)} :</strong> {alert.message}
        </div>
      )}
    </div>
  );
}
