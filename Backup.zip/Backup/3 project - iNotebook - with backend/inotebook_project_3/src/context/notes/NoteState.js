import React, { useState } from "react";
import noteContext from "./noteContext";

export function getToken() {
  return localStorage.getItem("token");
}

export default function NoteState(props) {
  const local = "http://localhost:5000";
  const [notes, setNotes] = useState([]);
  const [alert, setAlert] = useState(null);

  // Get all note
  const getNotes = async () => {
    const response = await fetch(`${local}/api/notes/getallnotes`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "auth-token": getToken(),
      },
    });
    const json = await response.json();
    console.log(json);
    setNotes(json);
  };

  // Add new note
  const addNote = async (title, description
    // , tag
    ) => {
    // API call
    const response = await fetch(`${local}/api/notes/createnote`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "auth-token": getToken(),
      },
      body: JSON.stringify({ title, description
        // , tag
       }),
    });
    const json = await response.json();
    const newNote = json;
    setNotes(notes.concat(newNote));
  };

  // Delete a note
  const deleteNote = async (id) => {
    // API call
    const response = await fetch(`${local}/api/notes/deletenote/${id}`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        "auth-token": getToken(),
      },
    });
    const json = await response.json();
    console.log(json);
    const filteredNote = notes.filter((notes) => {
      return notes._id !== id;
    });
    setNotes(filteredNote);
  };

  // Edit a note
  const editNote = async (id, title, description
    // , tag
    ) => {
    // API call
    const response = await fetch(`${local}/api/notes/updatenote/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        "auth-token": getToken(),
      },
      body: JSON.stringify({ title, description
        // , tag
       }),
    });
    const json = await response.json();
    console.log(json);
    const newNote = JSON.parse(JSON.stringify(notes));
    for (let i = 0; i < notes.length; i++) {
      const editedNote = notes[i];
      if (editedNote._id === id) {
        newNote[i].title = title;
        newNote[i].description = description;
        // newNote[i].tag = tag;
        break;
      }
      setNotes(newNote);
    }
  };

  const toggleAlert = (message, type) => {
    setAlert({
      message: message,
      type: type,
    });
    setTimeout(() => {
      setAlert(null);
    }, 900);
  };

  return (
    <noteContext.Provider
      value={{
        notes,
        addNote,
        deleteNote,
        editNote,
        getNotes,
        alert,
        toggleAlert,
      }}
    >
      {props.children}
    </noteContext.Provider>
  );
}
