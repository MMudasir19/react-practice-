const express = require("express");
const router = express.Router();
const { body, validationResult } = require("express-validator");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const getuserdetails = require("../middleware/getuserdetails");

const JWT_SECRET = "firstjwttoken";

// ROUTE 1 : create a user using: POST "/api/auth/createuser". No login required
router.post(
  "/createuser",
  [
    body("name", "Enter a valid Name").isLength({ min: 3 }),
    body("email", "Enter a valid Email").isEmail(),
    body("password", "Password must be atleast 5 digits").isLength({ min: 5 }),
  ],
  async (req, res) => {
    // Finds the validation errors in this request and wraps them in an object with handy functions
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    try {
      // check wether the user with this email exists already
      let user = await User.findOne({ email: req.body.email });
      if (user) {
        return res
          .status(400)
          .json({ error: "Sorry a user with this email already exists" });
      }

      // using bcrypt for password safety
      const hash = await bcrypt.hash(req.body.password, 10);

      // create new user
      user = await User.create({
        name: req.body.name,
        email: req.body.email,
        password: hash,
      });

      const token = jwt.sign({ id: user.id }, JWT_SECRET);
      res.json({ token });
    } catch (error) {
      // console.log(error.message);
      res.status(500).send("internal server error");
    }
  }
);

// ROUTE 2 : login user using: POST "/api/auth/loginuser". No login required
router.post(
  "/loginuser",
  [
    body("email", "Email is not correct").isEmail(),
    body("password", "Password can't be blank").exists(),
  ],
  async (req, res) => {
    let success = false;
    // Finds the validation errors in this request and wraps them in an object with handy functions
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success, errors: errors.array() });
    }
    try {
      // Destructuring
      const { email, password } = req.body;

      // check wether the user with this email exists
      let user = await User.findOne({ email });

      // if user types wrong email or password
      if (!user) {
        return res
          .status(400)
          .json({ success, error: "Please type correct information" });
      }

      // comparing typed password with saved password
      const passwordCompare = await bcrypt.compare(password, user.password);

      // if password is wrong
      if (!passwordCompare) {
        return res
          .status(400)
          .json({ success, error: "Please type correct Password" });
      }

      const data = {
        user: {
          id: user.id,
        },
      };
      const token = jwt.sign(data, JWT_SECRET);
      success = true;
      res.json({ success, token });
    } catch (error) {
      success = false;
      // console.log(error.message);
      res.status(500).send(success, "internal server error");
    }
  }
);

// ROUTE 3 : get logged in user details using: POST "/api/auth/userdetails". login required
router.post("/userdetails", getuserdetails, async (req, res) => {
  try {
    const userId = req.user.id;
    const user = await User.findById(userId).select("-password");
    res.send(user);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("internal server error 3");
  }
});

module.exports = router;
