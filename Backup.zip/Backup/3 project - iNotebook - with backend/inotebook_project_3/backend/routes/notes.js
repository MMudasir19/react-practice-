const express = require("express");
const router = express.Router();
const Note = require("../models/Note");
const getuserdetails = require("../middleware/getuserdetails");
const { body, validationResult } = require("express-validator");

// ROUTE 1 : get all notes of logged in user using: GET "/api/notes/getallnotes". login required
router.get("/getallnotes", getuserdetails, async (req, res) => {
  try {
    const notes = await Note.find({ user: req.user.id });
    res.json(notes);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("internal server error");
  }
});

// ROUTE 2 : create new note using: POST "/api/notes/createnote". login required
router.post(
  "/createnote",
  getuserdetails,
  [
    body("title", "Enter a valid title").isLength({ min: 1 }),
    body("description", "Enter a valid description").isLength({ min: 1 }),
  ],
  async (req, res) => {
    // Finds the validation errors in this request and wraps them in an object with handy functions
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { title, description
        // , tag
       } = req.body;
      const note = new Note({
        title,
        description,
        // tag,
        user: req.user.id,
      });
      // console.log(note);
      const savedNote = await note.save();
      res.json(savedNote);
    } catch (error) {
      console.error(error.message);
      res.status(500).send("internal server error");
    }
  }
);

// ROUTE 3 : update existing note using: PUT "/api/notes/updatenote/:id". login required
router.put("/updatenote/:id", getuserdetails, async (req, res) => {
  try {
    const { title, description
      // , tag
     } = req.body;

    // create a newNote Object
    const newNote = {};
    if (title) {
      newNote.title = title;
    }
    if (description) {
      newNote.description = description;
    }
    // if (tag) {
    //   newNote.tag = tag;
    // }

    // find the note by id and update it
    let note = await Note.findById(req.params.id);

    // if note doesn't exists then code ends here
    if (!note) {
      return res.status(404).send("Not Found");
    }

    // if someoneelse try to login
    if (note.user.toString() !== req.user.id) {
      return res.status(401).send("Not Allowed");
    }

    // find the note by id and update it
    note = await Note.findByIdAndUpdate(
      req.params.id,
      { $set: newNote },
      { new: true }
    );

    res.json({ note });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("internal server error");
  }
});

// ROUTE 4 : deleting existing note using: DELETE "/api/notes/deletenote/:id". login required
router.delete("/deletenote/:id", getuserdetails, async (req, res) => {
  try {
    // find the note by id
    let note = await Note.findById(req.params.id);

    // if note doesn't exists then code ends here
    if (!note) {
      return res.status(404).send("Not Found");
    }

    // if someoneelse try to login then code ends here
    if (note.user.toString() !== req.user.id) {
      return res.status(401).send("Not Allowed");
    }

    // find the note by id and delete it
    note = await Note.findByIdAndDelete(req.params.id);

    res.json({ success: "Note has been deleted", note: note });
  } catch (error) {
    console.error(error.message);
    res.status(500).send("internal server error");
  }
});

module.exports = router;
