const mongoose = require("mongoose");
const url = "mongodb+srv://asim:asim123@asim.0rdxbfx.mongodb.net/?retryWrites=true&w=majority";

main().catch(err => console.log(err));

async function main() {
  await mongoose.connect(url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
  // use `await mongoose.connect(url);`// if your database has auth enabled
}

const connectToMongo = () => { main() };

module.exports = connectToMongo;
