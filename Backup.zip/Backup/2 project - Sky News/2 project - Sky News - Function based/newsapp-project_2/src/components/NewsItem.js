import React from "react";

export default function NewsItem(props) {
  // let d3 = props.date;
  // let dn = new Date(d3);
  // dn.toGMTString();
  // let d3 = props.date;
  // let d1 = new Date(d3);
  // let dateFinal = d1.toUTCString();

  return (
    <div className="my-4">
      <div className="card dark" style={{ width: "24rem" }}>
        {/* <div className="card dark" > */}
        <img
          src={
            props.imageUrl
              ? props.imageUrl
              : "https://resize.indiatvnews.com/en/resize/newbucket/715_-/2020/08/breakingnews-live-blog-1568185450-1595123397-1597628266.jpg"
          }
          className="card-img-top"
          alt="."
          width={"100px"}
          height={"211px"}
        />
        <div className="card-body">
          <h5 className="card-title">
            {props.title
              ? props.title.substring(0, 94)
              : "PSL 2023: Muhammad Haris 'not satisfied' with his performance"}
            ...{" "}
            {/* {props.title.length < 110
                ? props.title
                : props.title.substring(0, 110)}... */}
          </h5>
          <p className="card-text">
            {props.description
              ? props.description.substring(0, 105)
              : "PSL 2023: Muhammad Haris 'not satisfied' with his performance."}
            ...{" "}
          </p>
          <p className="text-light-emphasis author-date">
            From : {props.author ? props.author.substring(0, 34) : "BBC"}
            <br />
            Date : {new Date(props.date).toUTCString().substring(0, 17)}
            {/* Date : {props.date.substring(0, 10) ? props.date.substring(0, 10) : "Sunday, 5 March 2023"} */}
            {/* Date : {d1 ? d1 : ".....Error"} */}
            {/* Date : {d1 ? d1 : "Sunday, 1 March 2023"} */}
          </p>
          <a
            href={
              props.newTabUrl
                ? props.newTabUrl
                : "https://www.geo.tv/latest/473515-the-hundred-top-pakistan-players-sign-up-for-season-3-draft"
            }
            className="btn btn-sm btn-primary"
          >
            View Details
          </a>
        </div>
      </div>
    </div>
  );
}

NewsItem.defaultProps = {
  imageUrl:
    "https://i.guim.co.uk/img/media/80cefb74d6860b55cc305905b584805213ba87ca/0_100_3000_1802/master/3000.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctb3BpbmlvbnMucG5n&enable=upscale&s=4cc4daba544585469ff17262f0e53bd6",
};
