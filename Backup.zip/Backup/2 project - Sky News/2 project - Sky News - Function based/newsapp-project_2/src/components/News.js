import React, { useEffect, useState } from "react";
import NewsItem from "./NewsItem";
import Loading from "./Loading";

const apiKey = "7bc85e6e86fd45b5b70c7db94bff9a2b";
// const apiKey = "7d4e5a914d6a40a6b0347f98c763cb24";
// const apiKey = "873fc440a83a4997ae6caa10f01cb5b6";

export default function News(props) {
  const [articles, setArticles] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [totalArticle, setTotalArticle] = useState(0);

  const getData = async () => {
    props.setProgress(30);
    let url = `https://newsapi.org/v2/everything?q=${
      props.searchKey ? props.searchKey : props.category
    }&from=${date()}&sortBy=popularity&searchin=title&pageSize=${
      props.pageSize
    }&page=${page || 1}&apiKey=${apiKey}`;
    setLoading(true);
    let response = await fetch(url);
    props.setProgress(70);
    let parsedData = await response.json();
    setArticles(parsedData.articles);
    setTotalArticle(parsedData.totalResults);
    setLoading(false);
    setPage(page || 1);
    props.setProgress(100);
  };

  useEffect(() => {
    document.title === 'BBC - Sky News'
    ? document.title = 'SkyNews - Top Headlines'
    : document.title = `${props.category} - Sky News`
    getData(); // await getData();
    /* eslint-disable */
  }, []);

    // componentDidUpdate(prevProps){
    //     if(props.searchKey !== prevProps.searchKey) {
    //         getData();
    //     }
    // }

  let handleNextPage = async () => {
    setPage(page + 1);
    getData();
  };

  let handlePreviousPage = async () => {
    setPage(page - 1);
    getData();
  };

  let date = () => {
    let d = "Date : Tue, 07 Mar 2023";
    let d1 = new Date(d);
    d1.setDate(d1.getDate() - 2);
    let dateFinal = d1.toUTCString();
    return dateFinal;
  };

//   const fetchMoreData = async () => {
//     let url = `https://newsapi.org/v2/everything?q=${
//       props.searchKey || props.category
//     }&from=${date()}&sortBy=popularity&searchin=title&pageSize=${
//       props.pageSize
//     }&page=${page + 1}&apiKey=${apiKey}`;
//     setPage(page + 1);
//     let response = await fetch(url);
//     let parsedData = await response.json();
//     setArticles(parsedData.articles);
//     setTotalArticle(parsedData.totalResults);
//   };

  return (
    <div className="container my-3">
      <h2
        className="d-flex justify-content-center mb-4"
        style={{ marginTop: "6.5%" }}
      >
        SkyNews - Top {props.category === "BBC" ? "" : props.category} Headlines
      </h2>
      <hr className="hr2  " />
      {loading && <Loading />}
      <div className="row">
        {!loading &&
          articles.map((e) => {
            return (
              <div className="col-md-4" key={e.url}>
                <NewsItem
                  title={e.title}
                  description={e.description}
                  imageUrl={e.urlToImage}
                  newTabUrl={e.url}
                  author={e.source.name}
                  date={e.publishedAt}
                />
              </div>
            );
          })}
      </div>
      <div className="container d-flex justify-content-between mt-4">
        <button
          disabled={page <= 1}
          className="btn btn-warning"
          onClick={handlePreviousPage}
        >
          <b>&lArr; Previous</b>
        </button>
        <button
          disabled={page + 1 > Math.ceil(totalArticle / 9) ? true : undefined}
          className="btn btn-warning nextButton"
          onClick={handleNextPage}
        >
          <b>Next &rArr;</b>
        </button>
      </div>
    </div>
  );
}

// author = {e.author}
// let d = new Date();
// d.toUTCString();
// console.log(d);
// return d
// let d1n = new Date(d);
// d1n.toUTCString();
// return d1n
// fromDate = ()=>{
//     let d = new Date()
//     d.setDate(d.getDate() - 1);
//     return d
// }
// toDate = ()=>{
//     let d2 = new Date();
//     return d2
// }
