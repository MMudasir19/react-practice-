// import React, {useState} from "react";
import React from "react";
import { Link, NavLink } from "react-router-dom";

export default function Navbar(props) {

  let activePage = (props) => {
    return {
      fontWeight: props?.isActive ? "bold" : "normal",
      // fontSize: props?.isActive ? "115%" : "100%",
    };
  };

  // const [searchBar, setSearchBar] = useState(second)

  // // let showSearchbar = ()=>{
  // //   setState({
  // //     hidden: state.hidden === 'hide' ? "display" : 'hide'
  // //   })
  // // }

  // handleKeyPress = (event) => {
  //   if (event.key === "Enter") {
  //     // console.log(state.searchBar);
  //     event.stopPropagation();
  //     event.preventDefault();
  //     // debugger
  //     props.onSearch(state.searchBar);
  //     setState({ searchBar: "" });
  //     document.title = `${state.searchBar} - Sky News`;
  //     // document.body.div.h2 = 'abc';
  //     // props.category = "";
  //     // setState({ category: "" });
  //   }
  // };

  // changeH2 = ()=>{
  // }
  // clearSearch = ()=>{
  //   // props.clearSearchBar(clearSearch)
  //   setState({
  //     searchBar: "",
  //   });
  // }

  // MyComponent() {
  //   const inputRef = useRef(null);
  //   const onButtonClick = () => {
  //     // @ts-ignore (us t his comment if typescript raises an error)
  //     inputRef.current.value = "";
  //   };
  // };

  // refs.someName.value = '';

  // clearSearchBar = () => {
  //   setState({
  //     searchBar : ''
  //   });
  // }

  // render(props) {
  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary fixed-top dark">
        <div className="container-fluid">
          <Link className="navbar-brand dark" to="/">
            {" "}
            {props.title}{" "}
          </Link>
          {/* <button onClick={()=>{showSearchbar()}}>hide</button>
            <form className={`d-flex ${state.hidden}`} role="search" >
                <input
                  className="searchbar"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                  value={state.searchBar}
                  onChange={(e) => {
                    // console.log(e.target.value)
                    setState({searchBar: e.target.value});
                  }}
                  onKeyDown={(e)=>{handleKeyPress(e)}}
                />
                <button
                  className="btn btn-outline-primary"
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation()
                    props.onSearch(state.searchBar);
                  }}
                >
                  Search
                </button>
              </form> */}

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className="collapse navbar-collapse dark"
            id="navbarSupportedContent"
          >
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link
                  // style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/"
                >
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  to="/About"
                >
                  About
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/General"
                >
                  General
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/Health"
                >
                  Health
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/Sports"
                >
                  Sports
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/Science"
                >
                  Science
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/Business"
                >
                  Business
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/Technology"
                >
                  Technology
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/Entertainment"
                >
                  Entertainment
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/Pakistan"
                >
                  Pakistan
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  style={activePage}
                  className="nav-link dark"
                  aria-current="page"
                  to="/PSL"
                >
                  PSL
                </NavLink>
              </li>
            </ul>

            {/* <form className="d-flex" role="search">
                <input
                  className="searchbar"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                  value={state.searchBar}
                  onChange={(e) => {
                    // console.log(e.target.value)
                    setState({ searchBar: e.target.value });
                  }}
                  onKeyDown={(e) => {
                    handleKeyPress(e);
                    // setState({ searchBar: null });
                  }}
                />
                <button
                  className="btn btn-outline-primary"
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    props.onSearch(state.searchBar);
                    props.clearSearch();
                    // setState({ searchBar: null });
                  }}
                >
                  Search
                </button>
              </form> */}
          </div>
        </div>
      </nav>
    </div>
  );
  // }
}
