import "./App.css";
import React, { useState } from "react";
import Navbar from "./components/Navbar";
import News from "./components/News";
import About from "./components/About";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoadingBar from "react-top-loading-bar";

export default function App(props) {
  // apiKey = process.env.REACT_APP_API;

  const pageSize = 9;
  const [searchKey, setSearchKey] = useState(null);
  const [progress, setProgress] = useState(0);

  const handleSearch = (searchKey) => {
    setSearchKey(searchKey);
  };

  const clearSearch = () => {
    setSearchKey(null);
  };

  return (
    <BrowserRouter>
      <Navbar
        title="Sky News"
        onSearch={handleSearch}
        clearSearch={clearSearch}
      />
      <LoadingBar
        height={2}
        color="cyan"
        // color='red'
        // color="white"
        progress={progress}
      />
      <Routes>
        <Route
          exact
          path="/"
          element={
            <News
              setProgress={setProgress}
              key="1"
              pageSize={pageSize}
              category="BBC"
              // category="world news"
              // category="Headlines"
              // category="General"
              searchKey={searchKey}
            />
          }
        />
        <Route exact path="/About" element={<About />} />
        <Route
          exact
          path="/Sports"
          element={
            <News
              setProgress={setProgress}
              key="2"
              pageSize={pageSize}
              category="Sports"
              searchKey={searchKey}
            />
          }
        />
        <Route
          exact
          path="/Science"
          element={
            <News
              setProgress={setProgress}
              key="3"
              pageSize={pageSize}
              category="Science"
              searchKey={searchKey}
            />
          }
        />
        <Route
          exact
          path="/Business"
          element={
            <News
              setProgress={setProgress}
              key="4"
              pageSize={pageSize}
              category="Business"
              searchKey={searchKey}
            />
          }
        />
        <Route
          exact
          path="/General"
          element={
            <News
              setProgress={setProgress}
              key="5"
              pageSize={pageSize}
              category="General"
              searchKey={searchKey}
            />
          }
        />
        <Route
          exact
          path="/Technology"
          element={
            <News
              setProgress={setProgress}
              key="6"
              pageSize={pageSize}
              category="Technology"
              searchKey={searchKey}
            />
          }
        />
        <Route
          exact
          path="/Entertainment"
          element={
            <News
              setProgress={setProgress}
              key="7"
              pageSize={pageSize}
              category="Entertainment"
              searchKey={searchKey}
            />
          }
        />
        <Route
          exact
          path="/Pakistan"
          element={
            <News
              setProgress={setProgress}
              key="8"
              pageSize={pageSize}
              category="Pakistan"
              searchKey={searchKey}
            />
          }
        />
        <Route
          exact
          path="/PSL"
          element={
            <News
              setProgress={setProgress}
              key="9"
              pageSize={pageSize}
              category="PSL"
              searchKey={searchKey}
            />
          }
        />
        <Route
          exact
          path="/Health"
          element={
            <News
              setProgress={setProgress}
              key="10"
              pageSize={pageSize}
              category="Health"
              searchKey={searchKey}
            />
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
