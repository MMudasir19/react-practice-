import React, { Component } from "react";
import { Link, NavLink } from "react-router-dom";

export default class Navbar extends Component {
  constructor() {
    super();
    this.state = {
      searchBar: "",
      // hidden: "hide",
    };
  }

  // showSearchbar = ()=>{
  //   this.setState({
  //     hidden: this.state.hidden === 'hide' ? "display" : 'hide'
  //   })
  // }

  handleKeyPress = (event) => {
    if (event.key === "Enter") {
      event.stopPropagation();
      event.preventDefault();
      // debugger
      this.props.onSearch(this.state.searchBar);
      this.setState({ searchBar: "" });
      document.title = `${this.state.searchBar} - Sky News`;
    }
    // this.props.clearSearch();
  };

  // changeH2 = ()=>{
  // }
  // clearSearch = ()=>{
  //   // this.props.clearSearchBar(this.clearSearch)
  //   this.setState({
  //     searchBar: "",
  //   });
  // }

  activePage = (props) => {
    return {
      fontWeight: props?.isActive ? "bold" : "normal",
      // color: props?.isActive ? "white" : "red"
    };
  };

  // MyComponent() {
  //   const inputRef = useRef(null);
  //   const onButtonClick = () => {
  //     // @ts-ignore (us this comment if typescript raises an error)
  //     inputRef.current.value = "";
  //   };
  // };

  // this.refs.someName.value = '';

  // clearSearchBar = () => {
  //   this.setState({
  //     searchBar : ''
  //   });
  // }

  render(props) {
    return (
      <div>
        <nav className="navbar navbar-expand-lg bg-body-tertiary dark fixed-top">
          <div className="container-fluid">
            <Link className="navbar-brand dark" to="/">
              {" "}
              {this.props.title}{" "}
            </Link>
            {/* <button onClick={()=>{this.showSearchbar()}}>hide</button>

            <form className={`d-flex ${this.state.hidden}`} role="search" >
                <input
                  className="searchbar"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                  value={this.state.searchBar}
                  onChange={(e) => {
                    // console.log(e.target.value)
                    this.setState({searchBar: e.target.value});
                  }}
                  onKeyDown={(e)=>{this.handleKeyPress(e)}}
                />
                <button
                  className="btn btn-outline-primary"
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation()
                    this.props.onSearch(this.state.searchBar);
                  }}
                >
                  Search
                </button>
              </form> */}

            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div
              className="collapse navbar-collapse dark"
              id="navbarSupportedContent"
            >
              <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <Link
                    // style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/"
                  >
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    to="/About"
                  >
                    About
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/General"
                  >
                    General
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/Health"
                  >
                    Health
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/Sports"
                  >
                    Sports
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/Science"
                  >
                    Science
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/Business"
                  >
                    Business
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/Technology"
                  >
                    Technology
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/Entertainment"
                  >
                    Entertainment
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/Pakistan"
                  >
                    Pakistan
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink
                    onClick={this.props.clearSearch}
                    style={this.activePage}
                    className="nav-link dark"
                    aria-current="page"
                    to="/PSL"
                  >
                    PSL
                  </NavLink>
                </li>
              </ul>

              <form className="d-flex" role="search">
                <input
                  className="searchbar"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                  value={this.state.searchBar}
                  onChange={(e) => {
                    this.setState({ searchBar: e.target.value });
                  }}
                  onKeyDown={(e) => {
                    this.handleKeyPress(e);
                  }}
                />
                <button
                  className="btn btn-outline-primary"
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    this.props.onSearch(this.state.searchBar);
                    this.props.clearSearch();
                  }}
                >
                  Search
                </button>
              </form>
            </div>
          </div>
        </nav>
      </div>
    );
  }
}
