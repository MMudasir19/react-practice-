import React, { Component } from "react";

export default class NewsItem extends Component {
  render(props) {
    return (
      <div className="my-4">
        <div className="card dark" style={{ width: "24rem" }}>
          <img
            src={
              this.props.imageUrl
                ? this.props.imageUrl
                : "https://resize.indiatvnews.com/en/resize/newbucket/715_-/2020/08/breakingnews-live-blog-1568185450-1595123397-1597628266.jpg"
            }
            className="card-img-top"
            alt="."
            width={"100px"}
            height={"211px"}
          />
          <div className="card-body">
            <h5 className="card-title">
              {this.props.title
                ? this.props.title.substring(0, 94)
                : "PSL 2023: Muhammad Haris 'not satisfied' with his performance"}
              ...{" "}
            </h5>
            <p className="card-text">
              {this.props.description
                ? this.props.description.substring(0, 105)
                : "PSL 2023: Muhammad Haris 'not satisfied' with his performance."}
              ...{" "}
            </p>
            <p className="text-light-emphasis author-date">
              From :{" "}
              {this.props.author ? this.props.author.substring(0, 34) : "BBC"}
              <br />
              Date : {new Date(this.props.date).toUTCString().substring(0, 17)}
            </p>
            <a
              href={
                this.props.newTabUrl
                  ? this.props.newTabUrl
                  : "https://www.geo.tv/latest/473515-the-hundred-top-pakistan-players-sign-up-for-season-3-draft"
              }
              className="btn btn-sm btn-primary"
            >
              View Details
            </a>
          </div>
        </div>
      </div>
    );
  }
}

NewsItem.defaultProps = {
  imageUrl: "1.jpg",
};
