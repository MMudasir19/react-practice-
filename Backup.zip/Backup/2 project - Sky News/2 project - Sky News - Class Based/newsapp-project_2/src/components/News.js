import React, { Component } from 'react'
import NewsItem from './NewsItem'
import Loading from './Loading';

const apiKey = "7bc85e6e86fd45b5b70c7db94bff9a2b";
// const apiKey = "7d4e5a914d6a40a6b0347f98c763cb24";
// const apiKey = "873fc440a83a4997ae6caa10f01cb5b6";

export default class News extends Component {

    constructor(props){
        super(props);
        this.state = {
            articles: [],
            page: 1,
            loading: false,
        }
        document.title === 'BBC - Sky News'
            ? document.title = 'SkyNews - Top Headlines'
            : document.title = `${this.props.category} - Sky News`
    }

    getData = async(page)=> {
        this.props.setProgress(30);
        let url = `https://newsapi.org/v2/everything?q=${this.props.searchKey || this.props.category}&from=${this.date()}&sortBy=popularity&searchin=title&pageSize=${this.props.pageSize}&page=${page || 1}&apiKey=${apiKey}`;
        this.setState({ loading: true });
        let response = await fetch(url);
        this.props.setProgress(70);
        let parsedData = await response.json();
        this.setState({
            articles: parsedData.articles,
            totalArticle: parsedData.totalResults,
            loading: false,
            page : page || 1,
        });
        this.props.setProgress(100);
    }
 
    async componentDidMount(){
        await this.getData();
    }
    componentDidUpdate(prevProps){
        if(this.props.searchKey !== prevProps.searchKey) {
            this.getData();
        }
    }

    handleNextPage = async () => {
        this.getData(this.state.page + 1)
    }

    handlePreviousPage = async () => {
        this.getData(this.state.page - 1)
    }

    date = ()=>{
        let d1 = new Date();
        d1.setDate(d1.getDate() - 6);
        let dateFinal = d1.toUTCString();
        return dateFinal
    }

    render() {
        return (
            <div className='container my-3'>
                <h2 className='d-flex justify-content-center mb-4' style={{ marginTop: "6.5%" }}>SkyNews - Top {this.props.category === 'BBC' ? '' : this.props.category} Headlines</h2>
                <hr className='hr2  '/>
                {this.state.loading && <Loading />}
                <div className="row">
                    {!this.state.loading && this.state.articles.map((e)=>{
                        return <div className="col-md-4" key={e.url}>
                            <NewsItem
                                title = {e.title} 
                                description = {e.description} 
                                imageUrl = {e.urlToImage} 
                                newTabUrl = {e.url}
                                author = {e.source.name}
                                date = {e.publishedAt}
                            />
                        </div>
                    })}
                </div>
                <div className="container d-flex justify-content-between mt-4">
                    <button disabled={this.state.page <= 1} className="btn btn-warning" onClick={this.handlePreviousPage}><b>&lArr; Previous</b></button>
                    <button disabled={this.state.page + 1 > Math.ceil(this.state.totalArticle/9) ? true : undefined} className="btn btn-warning nextButton" onClick={this.handleNextPage}><b>Next &rArr;</b></button>
                </div>
            </div>
        )
    }
}
