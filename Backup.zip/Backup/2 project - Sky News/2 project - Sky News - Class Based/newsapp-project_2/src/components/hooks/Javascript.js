// import { useState } from "react";

// export default function Javascript() {
//   const [theme, setTheme] = useState(true);
//   const toggleTheme = (cls) => {
//     if (theme === false) {
//       setTheme(true);
//       document.body.style.backgroundColor = "rgb(212, 205, 141)";
//     } else {
//       setTheme(false);
//       document.body.style.backgroundColor = "#02142e";
//     }
//   };

//   return { theme, toggleTheme };
// }