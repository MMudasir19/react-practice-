import "./App.css";
import React, { Component } from "react";
import Navbar from "./components/Navbar";
import News from "./components/News";
import About from "./components/About";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LoadingBar from "react-top-loading-bar";

export default class App extends Component {
  // apiKey = process.env.REACT_APP_API;

  constructor() {
    super();
    this.state = {
      searchKey: null,
      category: "",
      progress: 0,
    };
  }

  handleSearch = (searchKey) => {
    this.setState({ searchKey });
  };

  clearSearch = () => {
    this.setState({ searchKey: null });
  };

  setProgress = (progress) => {
    this.setState({ progress: progress }); //this keyword is useable only with arrow function till date.
  };

  render() {
    return (
      <BrowserRouter>
        <Navbar
          title="Sky News"
          onSearch={this.handleSearch}
          clearSearch={this.clearSearch}
        />
        <LoadingBar
          height={2}
          // color='red'
          color="cyan"
          // color="white"
          progress={this.state.progress}
        />
        <Routes>
          <Route
            exact
            path="/"
            element={
              <News
                setProgress={this.setProgress}
                key="1"
                pageSize="9"
                category="BBC"
                // category="world news"
                // category="Headlines"
                // category="General"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route exact path="/About" element={<About />} />
          <Route
            exact
            path="/Sports"
            element={
              <News
                setProgress={this.setProgress}
                key="2"
                pageSize="9"
                category="Sports"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route
            exact
            path="/Science"
            element={
              <News
                setProgress={this.setProgress}
                key="3"
                pageSize="9"
                category="Science"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route
            exact
            path="/Business"
            element={
              <News
                setProgress={this.setProgress}
                key="4"
                pageSize="9"
                category="Business"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route
            exact
            path="/General"
            element={
              <News
                setProgress={this.setProgress}
                key="5"
                pageSize="9"
                category="General"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route
            exact
            path="/Technology"
            element={
              <News
                setProgress={this.setProgress}
                key="6"
                pageSize="9"
                category="Technology"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route
            exact
            path="/Entertainment"
            element={
              <News
                setProgress={this.setProgress}
                key="7"
                pageSize="9"
                category="Entertainment"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route
            exact
            path="/Pakistan"
            element={
              <News
                setProgress={this.setProgress}
                key="8"
                pageSize="9"
                category="Pakistan"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route
            exact
            path="/PSL"
            element={
              <News
                setProgress={this.setProgress}
                key="9"
                pageSize="9"
                category="PSL"
                searchKey={this.state.searchKey}
              />
            }
          />
          <Route
            exact
            path="/Health"
            element={
              <News
                setProgress={this.setProgress}
                key="10"
                pageSize="9"
                category="Health"
                searchKey={this.state.searchKey}
              />
            }
          />
        </Routes>
      </BrowserRouter>
    );
  }
}
