const body = document.querySelector("body");
const btnHamburger = document.querySelector("#btnHamburger");
const headerLinks = document.querySelector("#header__links");
const overlay = document.querySelector("#overlay");
const header = document.querySelector("header");
const fadeItems = document.querySelectorAll(".fade");

const hamburger = () => {
  console.log("hamburger clicked");
  if (header.classList.contains("open")) {
    // Hamburger closed
    body.classList.remove("noScrolling");
    header.classList.remove("open");
    fadeItems.forEach((element) => {
      element.classList.remove("fadeIn");
      element.classList.add("fadeOut");
    });
  } else {
    // Hamburger opened
    body.classList.add("noScrolling");
    header.classList.add("open");
    fadeItems.forEach((element) => {
      element.classList.add("fadeIn");
      element.classList.remove("fadeOut");
    });
  }
};
