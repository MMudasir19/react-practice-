import React from "react";

export default function About(props) {
  return (
    <div className={`container text-${props.theme === false ? 'light' : 'dark'}`}>
      <h1 className="centerAbout my-3">ABOUT</h1>
      <div className="accordion" id="accordionPanelsStayOpenExample">
        <div className="accordion-item">
          <h2 className="accordion-header" id="panelsStayOpen-headingOne">
            <button
              className={`accordion-button text-${props.theme === false ? 'light' : 'dark'}`}
              style={{backgroundColor: props.theme === false ? '#263238' : 'orange'}}
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#panelsStayOpen-collapseOne"
              aria-expanded="true"
              aria-controls="panelsStayOpen-collapseOne">
              <strong>What is TextUtils ?</strong>
            </button>
          </h2>
          <div
            id="panelsStayOpen-collapseOne"
            className={`accordion-collapse collapse show text-${props.theme === false ? 'light' : 'dark'}`}
            style={{backgroundColor: props.theme === false ? '#1b1c27' : 'khaki'}}
            aria-labelledby="panelsStayOpen-headingOne">
            <div className="accordion-body">
            <strong>TextUtils</strong> is a website that offers a variety of text-related tools and resources to help users manipulate and format text more efficiently. The website was created to serve as a one-stop-shop for individuals and businesses looking to improve their written communication.
            The website offers a range of tools that can be used to perform various tasks, such as converting text to lowercase or uppercase, removing line breaks, counting words and characters, generating random text, and much more. The tools are user-friendly and easy to navigate, allowing users to quickly access the function they need and perform their desired actions with just a few clicks.

            </div>
          </div>
        </div>
        <div className="accordion-item ">
          <h2 className="accordion-header " id="panelsStayOpen-headingTwo">
            <button
              className={`accordion-button collapsed text-${props.theme === false ? 'light' : 'dark'}`}
              style={{backgroundColor: props.theme === false ? '#263238' : 'orange'}}
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#panelsStayOpen-collapseTwo"
              aria-expanded="false"
              aria-controls="panelsStayOpen-collapseTwo"
            >
              <strong>Text Tools</strong>
            </button>
          </h2>
          <div
            id="panelsStayOpen-collapseTwo"
            className={`accordion-collapse collapse show text-${props.theme === false ? 'light' : 'dark'}`}
            style={{backgroundColor: props.theme === false ? '#1b1c27' : 'khaki'}}
            aria-labelledby="panelsStayOpen-headingTwo"
          >
            <div className="accordion-body">
            <strong>Variety of Tools:</strong> TextUtils includes a variety of tools that are designed to help users manipulate and format text more efficiently. Some of the most popular tools in this section include:
            In addition to its tools, TextUtils also offers a variety of resources to help users improve their writing skills. These resources include a blog section that provides tips and tricks for writing more effectively, as well as articles on grammar, punctuation, and other aspects of writing that are essential for producing high-quality content.

            </div>
          </div>
        </div>
        <div className="accordion-item ">
          <h2 className="accordion-header " id="panelsStayOpen-headingThree">
            <button
              className={`accordion-button collapsed text-${props.theme === false ? 'light' : 'dark'}`}
              style={{backgroundColor: props.theme === false ? '#263238' : 'orange'}}
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#panelsStayOpen-collapseThree"
              aria-expanded="false"
              aria-controls="panelsStayOpen-collapseThree"
            >
              <strong>Why TextUtils ?</strong>
            </button>
          </h2>
          <div
            id="panelsStayOpen-collapseThree"
            className={`accordion-collapse collapse show text-${props.theme === false ? 'light' : 'dark'}`}
            style={{backgroundColor: props.theme === false ? '#1b1c27' : 'khaki'}}
            aria-labelledby="panelsStayOpen-headingThree"
          >
            <div className="accordion-body ">
            <strong>Writing Resources:</strong> TextUtils includes a variety of resources that are designed to help users improve their writing skills. Some of the most popular resources in this section include:
            The TextUtils blog provides tips and tricks for writing more effectively, as well as articles on grammar, punctuation, and other aspects of writing that are essential for producing high-quality content.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}